
export interface Freight {
  id: string;
  date: string; // ISO Date string
  client: string;
  totalValue: number;
  
  // Distribution values (Calculated based on Total)
  companyValue: number;
  driverValue: number;
  reserveValue: number;
  
  // Percentages
  companyPercent: number;
  driverPercent: number;
  reservePercent: number;

  // Payment Status
  status: 'PAID' | 'PARTIAL' | 'PENDING';
  receivedValue: number; // Amount actually received (Cash flow)
  pendingValue: number;  // Amount to receive (Receivable)
  dueDate?: string;      // Date to receive the pending amount
}

export interface Booking {
  id: string;
  date: string;
  client: string;
  time?: string;
  estimatedValue?: number;
  status: 'SCHEDULED' | 'COMPLETED' | 'CANCELLED';
}

export type ExpenseSource = 'COMPANY' | 'DRIVER' | 'RESERVE';

export type ExpenseCategory = 'FUEL' | 'MAINTENANCE' | 'TOLL' | 'FOOD' | 'OTHER';

export interface Expense {
  id: string;
  date: string;
  description: string;
  value: number;
  source: ExpenseSource;
  category?: ExpenseCategory;
}

export interface User {
  id: string;
  name: string;
  cpf: string;
  email: string;
  password: string; 
  createdAt: string; // ISO Date do cadastro
  isPremium: boolean; // Status da assinatura
  
  // Referral System
  referralCode?: string;      
  referredBy?: string;        
  referralBalance?: number;   
  referralCount?: number;     
}

export interface GoalHistoryEntry {
  month: string; // YYYY-MM
  goal: number;
  achieved: number;
}

export interface AppSettings {
  defaultCompanyPercent: number;
  defaultDriverPercent: number;
  defaultReservePercent: number;
  theme: 'light' | 'dark';
  monthlyGoal?: number; 
  monthlyGoalDeadline?: string;
  goalHistory?: GoalHistoryEntry[]; 
  
  // Receipt Issuer Details
  issuerName?: string;
  issuerDoc?: string; 
  issuerPhone?: string;
  
  // Address Details
  issuerAddressStreet?: string;
  issuerAddressNumber?: string;
  issuerAddressNeighborhood?: string;
  issuerAddressCity?: string;
  issuerAddressState?: string;
  issuerAddressZip?: string;
}

export type ViewState = 'DASHBOARD' | 'ADD_FREIGHT' | 'ADD_EXPENSE' | 'HISTORY' | 'RECEIVABLES' | 'SETTINGS' | 'CALCULATOR' | 'AGENDA' | 'REFERRAL' | 'GOALS' | 'PAYMENT';

export interface DashboardStats {
  monthTotal: number;
  weekTotal: number;
  totalCompany: number; 
  totalDriver: number;  
  totalReserve: number; 
  totalPending: number; 
}