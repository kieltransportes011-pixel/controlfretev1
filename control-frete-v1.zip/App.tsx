import React, { useState, useEffect } from 'react';
import { ViewState, Freight, Expense, AppSettings, User } from './types';
import { Layout } from './components/Layout';
import { Dashboard } from './components/Dashboard';
import { AddFreight } from './components/AddFreight';
import { AddExpense } from './components/AddExpense';
import { History } from './components/History';
import { Schedule } from './components/Schedule';
import { Settings } from './components/Settings';
import { FreightCalculator } from './components/FreightCalculator';
import { Auth } from './components/Auth';
import { ReferralSystem } from './components/ReferralSystem';
import { MonthlyGoal } from './components/MonthlyGoal';
import { Button } from './components/Button';
import { Paywall } from './components/Paywall';
import { auth, db } from './firebase';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { doc, getDoc, setDoc, onSnapshot, collection, query, deleteDoc, orderBy } from 'firebase/firestore';
import { Loader2, ShieldAlert, Database, Cloud, Clock } from 'lucide-react';

const SAFE_DEFAULT_SETTINGS: AppSettings = {
    defaultCompanyPercent: 40,
    defaultDriverPercent: 40,
    defaultReservePercent: 20,
    theme: 'light'
}

const sanitizeForFirestore = (obj: any) => {
    const clean: any = {};
    Object.keys(obj).forEach(key => {
        const val = obj[key];
        if (val !== undefined && val !== null) {
            if (typeof val === 'object' && !Array.isArray(val)) {
                clean[key] = sanitizeForFirestore(val);
            } else {
                clean[key] = val;
            }
        }
    });
    return clean;
};

const App: React.FC = () => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [initializing, setInitializing] = useState(true);
  const [view, setView] = useState<ViewState>('DASHBOARD');
  const [freights, setFreights] = useState<Freight[]>([]);
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [settings, setSettings] = useState<AppSettings>(SAFE_DEFAULT_SETTINGS);
  const [formData, setFormData] = useState<Partial<Freight> | undefined>(undefined);
  const [permissionError, setPermissionError] = useState(false);
  const [syncing, setSyncing] = useState(false);

  // Auth Listener
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userDoc = await getDoc(doc(db, "users", firebaseUser.uid));
          if (userDoc.exists()) {
            setCurrentUser(userDoc.data() as User);
          } else {
            signOut(auth);
          }
        } catch (e: any) {
          if (e.code === 'permission-denied') setPermissionError(true);
        }
      } else {
        setCurrentUser(null);
      }
      setInitializing(false);
    });
    return () => unsubscribe();
  }, []);

  // Hash Navigation Handler for Payment
  useEffect(() => {
    const handleHashChange = () => {
        if (window.location.hash === '#PAYMENT') {
            setView('PAYMENT');
        }
    };
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  // Firestore Real-time Sync
  useEffect(() => {
    if (!currentUser) return;

    setSyncing(true);
    
    // User profile listener
    const unsubUser = onSnapshot(doc(db, "users", currentUser.id), (snap) => {
        if (snap.exists()) {
            setCurrentUser(snap.data() as User);
        }
    });

    // 1. Settings
    const unsubSettings = onSnapshot(doc(db, "settings", currentUser.id), (snap) => {
      if (snap.exists()) {
        setSettings(snap.data() as AppSettings);
      } else {
        const defaultSet = { ...SAFE_DEFAULT_SETTINGS, issuerName: currentUser.name };
        setDoc(doc(db, "settings", currentUser.id), sanitizeForFirestore(defaultSet));
      }
    }, (error) => {
      if (error.code === 'permission-denied') setPermissionError(true);
    });

    // 2. Freights
    const unsubFreights = onSnapshot(query(collection(db, "users", currentUser.id, "freights"), orderBy("date", "desc")), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Freight));
      setFreights(data);
      setSyncing(false);
    }, (error) => {
      if (error.code === 'permission-denied') setPermissionError(true);
    });

    // 3. Expenses
    const unsubExpenses = onSnapshot(query(collection(db, "users", currentUser.id, "expenses"), orderBy("date", "desc")), (snap) => {
      const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Expense));
      setExpenses(data);
    }, (error) => {
      if (error.code === 'permission-denied') setPermissionError(true);
    });

    return () => {
      unsubUser();
      unsubSettings();
      unsubFreights();
      unsubExpenses();
    };
  }, [currentUser?.id]);

  // Dark Mode
  useEffect(() => {
    if (settings.theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [settings.theme]);

  const handleLogout = async () => {
    await signOut(auth);
    setCurrentUser(null);
    setPermissionError(false);
  };

  const handleUpdateUser = async (updatedUser: User) => {
    if (!currentUser) return;
    try {
      setCurrentUser(updatedUser);
      await setDoc(doc(db, "users", currentUser.id), sanitizeForFirestore(updatedUser));
    } catch (e: any) {
      if (e.code === 'permission-denied') setPermissionError(true);
    }
  };

  const checkTrialExpired = () => {
    if (!currentUser || currentUser.isPremium) return false;
    const trialDays = 7;
    const start = new Date(currentUser.createdAt);
    const now = new Date();
    const diffMs = now.getTime() - start.getTime();
    const diffDays = diffMs / (1000 * 60 * 60 * 24);
    return diffDays >= trialDays;
  };

  const isExpired = checkTrialExpired();

  if (initializing) {
    return (
      <div className="min-h-screen bg-slate-50 dark:bg-slate-950 flex flex-col items-center justify-center space-y-4">
        <Loader2 className="w-10 h-10 text-brand animate-spin" />
        <p className="text-slate-400 font-medium animate-pulse">Carregando...</p>
      </div>
    );
  }

  if (!currentUser) {
    return <Auth onLogin={setCurrentUser} />;
  }

  if (isExpired && !currentUser.isPremium) {
    return <Paywall user={currentUser} onPaymentSuccess={() => {
        handleUpdateUser({ ...currentUser, isPremium: true });
        setView('DASHBOARD');
    }} />;
  }

  return (
    <Layout currentView={view} onNavigate={(v) => {
        setView(v);
        if (v !== 'ADD_FREIGHT') setFormData(undefined);
        if (window.location.hash) window.history.replaceState(null, '', ' ');
    }}>
      {syncing && (
         <div className="fixed top-2 right-2 z-50 bg-brand/10 backdrop-blur-sm p-1.5 rounded-full flex items-center gap-1.5 border border-brand/20">
            <Cloud className="w-3 h-3 text-brand animate-pulse" />
            <span className="text-[8px] font-bold text-brand uppercase tracking-tighter">Sincronizando...</span>
         </div>
      )}

      {permissionError && (
        <div className="fixed inset-0 z-[100] bg-slate-900/95 backdrop-blur-xl flex items-center justify-center p-6 animate-fadeIn">
          <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 max-w-sm w-full shadow-2xl space-y-6 border border-slate-200 dark:border-slate-800">
            <div className="flex flex-col items-center text-center space-y-4">
              <div className="bg-red-100 dark:bg-red-900/30 p-5 rounded-3xl">
                <ShieldAlert className="w-12 h-12 text-red-600 dark:text-red-400" />
              </div>
              <h2 className="text-2xl font-black text-slate-800 dark:text-white">Erro de Permissão</h2>
              <p className="text-sm text-slate-500 dark:text-slate-400">
                Não foi possível conectar ao banco de dados.
              </p>
            </div>
            <Button fullWidth onClick={() => window.location.reload()}>
              Recarregar
            </Button>
          </div>
        </div>
      )}

      {view === 'DASHBOARD' && (
        <Dashboard 
          user={currentUser}
          freights={freights} 
          expenses={expenses}
          onAddFreight={() => { setFormData(undefined); setView('ADD_FREIGHT'); }} 
          onAddExpense={() => setView('ADD_EXPENSE')}
          onViewSchedule={() => setView('RECEIVABLES')}
          onOpenCalculator={() => setView('CALCULATOR')}
          onViewGoals={() => setView('GOALS')}
        />
      )}
      
      {view === 'ADD_FREIGHT' && (
        <AddFreight 
          settings={settings}
          onSave={async (f) => {
              if (!currentUser) return;
              await setDoc(doc(db, "users", currentUser.id, "freights", f.id), sanitizeForFirestore(f));
              setView('DASHBOARD');
          }}
          onCancel={() => setView('DASHBOARD')}
          initialData={formData}
        />
      )}

      {view === 'ADD_EXPENSE' && (
        <AddExpense 
            onSave={async (e) => {
                if (!currentUser) return;
                await setDoc(doc(db, "users", currentUser.id, "expenses", e.id), sanitizeForFirestore(e));
                setView('DASHBOARD');
            }} 
            onCancel={() => setView('DASHBOARD')} 
        />
      )}

      {view === 'HISTORY' && (
        <History 
            freights={freights} 
            expenses={expenses} 
            onDeleteFreight={async (id) => {
                if (!currentUser) return;
                await deleteDoc(doc(db, "users", currentUser.id, "freights", id));
            }}
            onDeleteExpense={async (id) => {
                if (!currentUser) return;
                await deleteDoc(doc(db, "users", currentUser.id, "expenses", id));
            }}
            onEditFreight={(f) => { setFormData(f); setView('ADD_FREIGHT'); }}
            settings={settings}
        />
      )}

      {view === 'RECEIVABLES' && (
        <Schedule 
            freights={freights} 
            onReceivePayment={async (freightId) => {
                try {
                    const f = freights.find(item => item.id === freightId);
                    if (f && currentUser) {
                        // Limpando campos de pendência e vencimento
                        const updated = {
                            ...f,
                            status: 'PAID' as const,
                            receivedValue: f.totalValue,
                            pendingValue: 0,
                            dueDate: undefined 
                        };
                        
                        // O sanitizer removerá o campo 'dueDate' do documento por ser undefined
                        await setDoc(doc(db, "users", currentUser.id, "freights", freightId), sanitizeForFirestore(updated));
                    }
                } catch (error) {
                    console.error("Erro ao salvar recebimento:", error);
                    alert("Erro ao salvar no banco de dados.");
                    throw error;
                }
            }} 
        />
      )}

      {view === 'CALCULATOR' && (
        <FreightCalculator onCancel={() => setView('DASHBOARD')} onRegister={(d) => { setFormData(d); setView('ADD_FREIGHT'); }} />
      )}

      {view === 'REFERRAL' && (
        <ReferralSystem user={currentUser} onUpdateUser={handleUpdateUser} onBack={() => setView('SETTINGS')} />
      )}

      {view === 'GOALS' && (
        <MonthlyGoal 
            freights={freights} 
            settings={settings} 
            onUpdateSettings={async (s) => {
                if (!currentUser) return;
                setSettings(s);
                await setDoc(doc(db, "settings", currentUser.id), sanitizeForFirestore(s));
            }} 
            onBack={() => setView('DASHBOARD')}
        />
      )}

      {view === 'SETTINGS' && (
        <div className="space-y-6">
           <Settings 
                settings={settings} 
                user={currentUser} 
                onSave={async (s) => {
                    if (!currentUser) return;
                    setSettings(s);
                    await setDoc(doc(db, "settings", currentUser.id), sanitizeForFirestore(s));
                }} 
                onNavigate={setView}
            />
           <div className="px-4 pb-20">
              <button 
                onClick={handleLogout}
                className="w-full py-3 rounded-xl border-2 border-red-100 text-red-600 font-bold hover:bg-red-50 dark:border-red-900/30 dark:bg-red-900/10 dark:text-red-400 transition-colors"
              >
                Sair da Conta
              </button>
           </div>
        </div>
      )}

      {view === 'PAYMENT' && (
        <Paywall 
            user={currentUser} 
            onPaymentSuccess={() => {
                handleUpdateUser({ ...currentUser, isPremium: true });
                setView('SETTINGS');
            }} 
            onCancel={() => setView('SETTINGS')}
        />
      )}
    </Layout>
  );
};

export default App;