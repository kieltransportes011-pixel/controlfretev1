
import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
import { getFunctions } from "firebase/functions";

const firebaseConfig = {
  apiKey: "AIzaSyD1ZAvas4fsGw0o5zXjcITsrQSk3Y6gTME",
  authDomain: "control-frete.firebaseapp.com",
  projectId: "control-frete",
  storageBucket: "control-frete.firebasestorage.app",
  messagingSenderId: "740070336268",
  appId: "1:740070336268:web:dd0fa9075fabeae9eb4b29"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);
export const functions = getFunctions(app, 'us-central1'); // Ajuste a região se necessário
